package Restoutils;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
@ApplicationPath("rest")
public class RestAcivator extends Application {
        // Cette classe est vide mais active JAX-RS pour votre application.
    }

