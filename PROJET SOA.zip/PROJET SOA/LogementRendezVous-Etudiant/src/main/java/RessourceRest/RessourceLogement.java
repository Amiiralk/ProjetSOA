package RessourceRest;
import com.fasterxml.jackson.module.jaxb.ser.DomElementJsonSerializer;
import entities.Logement;
import metiers.LogementBusiness;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.util.ArrayList;
import java.util.List;

@Path("logements")
public class RessourceLogement {

        private static List<Logement> logements = new ArrayList<>();
        public static LogementBusiness logB= new LogementBusiness();

        // Ajouter un nouveau logement (POST)
        @POST
        @Consumes(MediaType.APPLICATION_XML)
        public Response createLogement(Logement logement) {
            if (logB.addLogement(logement)) {
                return Response.status(Response.Status.CREATED).build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
        }
    // Récupérer tous les logements (GET)
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllLogements() {
            if(logB.getLogements().size()!=0)
            {
                return Response.status(Response.Status.OK).entity(logB.getLogements()).build();}
            else
                return Response.status(Status.NO_CONTENT).build();


    }

}
